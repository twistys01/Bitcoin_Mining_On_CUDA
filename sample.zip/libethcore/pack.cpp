#include<libethcore\pack.h>

HANDLE stratumThread=NULL;
 bool isInitOver = false;
 int deviceCount=0;