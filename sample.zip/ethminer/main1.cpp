#pragma once
#pragma comment( lib, "ethcore.lib")
#include<libethcore\EthashCUDAMiner.h>
#include<libethcore\Farm.h>
#include<libethcore\Miner.h>
#include<iostream>
using namespace dev;
using namespace eth;
int main(int __argc,char** argv)
{
	string sa;
	for (int i = 0; i < __argc; ++i){
		string ssa = argv[i];
		if (ssa=="-c")
			sa = argv[++i];
	}
	
	int idcard = atoi(sa.c_str());
	EthashCUDAMiner* s = new EthashCUDAMiner(idcard);
	s->workLoop();
}